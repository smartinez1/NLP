# NLP
## Tareas, talleres y otros
repositorio clase procesamiento de lenguaje natural
